Version 4
SymbolType CELL
LINE Normal -32 48 -48 48
LINE Normal -32 80 -48 80
LINE Normal 64 64 32 64
LINE Normal 32 32 -32 32
LINE Normal 32 96 32 32
LINE Normal -32 96 32 96
LINE Normal -32 32 -32 96
LINE Normal 48 64 32 55
TEXT -13 48 Left 0 =1
WINDOW 0 -16 16 Left 0
WINDOW 3 -32 112 Left 0
SYMATTR Value CD4077B
SYMATTR Prefix X
SYMATTR SpiceModel VDD 0
SYMATTR Description 2-input Exclusive-NOR gate
SYMATTR SpiceLine VDD=5  SPEED=1.0  TRIPDT=5e-9
PIN -48 48 NONE 0
PINATTR PinName A
PINATTR SpiceOrder 1
PIN -48 80 NONE 0
PINATTR PinName B
PINATTR SpiceOrder 2
PIN 64 64 NONE 0
PINATTR PinName Y
PINATTR SpiceOrder 3
